# pong
The base code structure for a pong game.

Create your own github account and "fork" this project.

then clone the fork of this project to your computer:
 - use "gitshell" to navigate to your destination folder example d:ma/periode2/dip/github
 - type git clone https://github.com/erwinhenraat/pong.git
 - then enter the project folder by typing "cd pong"
 - you should see the blue master indicator

try changing some code and then make a snapshot

first add up all the changes on the stage 
type: git add -A

Then make a "commit" (a snapshot of your code)
type: git commit -m "comment on your change to the code"

Then push your changed version of the code back to your github account
type:git push


